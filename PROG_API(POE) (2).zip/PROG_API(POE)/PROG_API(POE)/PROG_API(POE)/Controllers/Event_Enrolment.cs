﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using PROG_API_POE_.Database;
using PROG_API_POE_.Models;

namespace PROG_API_POE_.Controllers
{ 
    
    [Route("api/[controller]")]
    [ApiController]
    
    public class Event_Enrolment : ControllerBase
    {
        private readonly Enrolment enrolmentDatabase = new Enrolment();

        // POST: /api/enrolments
        [HttpPost("enrolments")]
        public IActionResult CreateEnrolment(
            [FromBody] CreateEnrolmentRequest request,
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            if (request.CategoryId <= 0 || request.RouteId <= 0)
                return BadRequest("Valid category and route IDs are required.");

            int participantId =
                enrolmentDatabase.GetParticipantId(email, password);

            if (participantId == 0)
                return Unauthorized("Valid participant credentials are required.");

            try
            {
                var result = enrolmentDatabase.CreateEnrolment(
                    participantId, request);

                switch (result.Status)
                {
                    case EnrolmentCreateStatus.Created:
                        return Created(
                            $"/api/enrolments/{result.Enrolment!.EnrollmentID}",
                            result.Enrolment);

                    case EnrolmentCreateStatus.AlreadyEnrolled:
                        return BadRequest(
                            "You are already enrolled in this event.");

                    default:
                        return NotFound(
                            "The selected category or route was not found, or they belong to different events.");
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while creating the enrolment.");
            }
        }

        // GET: /api/enrolments/myenrolments
        [HttpGet("enrolments/myenrolments")]
        public IActionResult GetMyEnrolments(
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            int participantId =
                enrolmentDatabase.GetParticipantId(email, password);

            if (participantId == 0)
                return Unauthorized("Valid participant credentials are required.");

            try
            {
                return Ok(
                    enrolmentDatabase.GetMyEnrolments(participantId));
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while retrieving enrolments.");
            }
        }

        // GET: /api/categories/{categoryId}/enrolments
        [HttpGet("categories/{categoryId}/enrolments")]
        public IActionResult GetCategoryEnrolments(
            int categoryId,
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            if (categoryId <= 0)
                return BadRequest("Invalid category ID.");

            int organizerId =
                enrolmentDatabase.GetOrganizerId(email, password);

            if (organizerId == 0)
                return Unauthorized("Valid organizer credentials are required.");

            try
            {
                if (!enrolmentDatabase.OrganizerOwnsCategory(
                    categoryId, organizerId))
                {
                    return Forbid();
                }

                return Ok(
                    enrolmentDatabase.GetCategoryEnrolments(categoryId));
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while retrieving category enrolments.");
            }
        }

        // DELETE: /api/enrolments/{id}
        [HttpDelete("enrolments/{id}")]
        public IActionResult DeleteEnrolment(
            int id,
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            if (id <= 0)
                return BadRequest("Invalid enrolment ID.");

            try
            {
                var result = enrolmentDatabase.DeleteEnrolment(
                    id, email, password);

                switch (result)
                {
                    case EnrolmentDeleteStatus.Deleted:
                        return NoContent();

                    case EnrolmentDeleteStatus.NotFound:
                        return NotFound("Enrolment not found.");

                    default:
                        return Forbid();
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while deleting the enrolment.");
            }
        }
    }
}

