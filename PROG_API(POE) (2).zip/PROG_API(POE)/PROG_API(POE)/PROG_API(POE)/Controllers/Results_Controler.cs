﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.ComponentModel.DataAnnotations;
using PROG_API_POE_.Models;

namespace PROG_API_POE_.Controllers
{ 
    [Route("api/[controller]")]
    [ApiController]
   
    public class ResultsController : ControllerBase
    {
        private readonly PROG_API_POE_.Database.Result resultDatabase =
            new PROG_API_POE_.Database.Result();

        private bool IsValidRequest(ResultRequest request)
        {
            if (!Enum.IsDefined(typeof(ResultStatus), request.Status))
                return false;

            if (request.FinishTime.HasValue &&
                request.FinishTime.Value < TimeSpan.Zero)
                return false;

            if (request.Position.HasValue && request.Position.Value <= 0)
                return false;

            if (request.Status == ResultStatus.Finished)
            {
                return request.FinishTime.HasValue &&
                       request.Position.HasValue;
            }

            return true;
        }

        // POST /api/enrolments/{enrolmentId}/result
        [HttpPost("enrolments/{enrolmentId}/result")]
        public IActionResult CreateResult(
            int enrolmentId,
            [FromBody] ResultRequest request,
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            if (enrolmentId <= 0)
                return BadRequest("Invalid enrolment ID.");

            if (!IsValidRequest(request))
                return BadRequest(
                    "Provide a valid status. Finished participants need a finish time and position.");

            try
            {
                int organizerId =
                    resultDatabase.GetOrganizerId(email, password);

                if (organizerId == 0)
                    return Unauthorized("Valid organiser credentials are required.");

                if (!resultDatabase.EnrolmentExists(enrolmentId))
                    return NotFound("Enrolment not found.");

                if (!resultDatabase.OrganizerOwnsEnrolment(
                    enrolmentId, organizerId))
                    return Forbid();

                if (resultDatabase.ResultExistsForEnrolment(enrolmentId))
                    return Conflict("A result already exists for this enrolment.");

                ResultModel created =
                    resultDatabase.CreateResult(enrolmentId, request);

                return StatusCode(201, created);
            }
            catch (SqlException ex) when (ex.Number == 2601 || ex.Number == 2627)
            {
                return Conflict("A result already exists for this enrolment.");
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while creating the result.");
            }
        }

        // GET /api/enrolments/{enrolmentId}/result
        [HttpGet("enrolments/{enrolmentId}/result")]
        public IActionResult GetResult(
            int enrolmentId,
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            if (enrolmentId <= 0)
                return BadRequest("Invalid enrolment ID.");

            try
            {
                if (!resultDatabase.EnrolmentExists(enrolmentId))
                    return NotFound("Enrolment not found.");

                int participantId =
                    resultDatabase.GetParticipantId(email, password);

                int organizerId =
                    resultDatabase.GetOrganizerId(email, password);

                if (participantId == 0 && organizerId == 0)
                    return Unauthorized("Valid user credentials are required.");

                bool allowed =
                    (participantId > 0 &&
                     resultDatabase.ParticipantOwnsEnrolment(
                         enrolmentId, participantId))
                    ||
                    (organizerId > 0 &&
                     resultDatabase.OrganizerOwnsEnrolment(
                         enrolmentId, organizerId));

                if (!allowed)
                    return Forbid();

                ResultModel? result =
                    resultDatabase.GetResultByEnrolment(enrolmentId);

                if (result == null)
                    return NotFound("A result has not yet been recorded.");

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while retrieving the result.");
            }
        }

        // PUT /api/results/{id}
        [HttpPut("results/{id}")]
        public IActionResult UpdateResult(
            int id,
            [FromBody] ResultRequest request,
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            if (id <= 0)
                return BadRequest("Invalid result ID.");

            if (!IsValidRequest(request))
                return BadRequest(
                    "Provide a valid status. Finished participants need a finish time and position.");

            try
            {
                ResultModel? existing = resultDatabase.GetResultById(id);

                if (existing == null)
                    return NotFound("Result not found.");

                int organizerId =
                    resultDatabase.GetOrganizerId(email, password);

                if (organizerId == 0)
                    return Unauthorized("Valid organiser credentials are required.");

                if (!resultDatabase.OrganizerOwnsEnrolment(
                    existing.EnrollmentID, organizerId))
                    return Forbid();

                ResultModel? updated =
                    resultDatabase.UpdateResult(id, request);

                return updated == null ? NotFound() : Ok(updated);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while updating the result.");
            }
        }

        // DELETE /api/results/{id}
        [HttpDelete("results/{id}")]
        public IActionResult DeleteResult(
            int id,
            [FromHeader(Name = "X-User-Email"), Required] string email,
            [FromHeader(Name = "X-User-Password"), Required] string password)
        {
            if (id <= 0)
                return BadRequest("Invalid result ID.");

            try
            {
                ResultModel? existing = resultDatabase.GetResultById(id);

                if (existing == null)
                    return NotFound("Result not found.");

                int organizerId =
                    resultDatabase.GetOrganizerId(email, password);

                if (organizerId == 0)
                    return Unauthorized("Valid organiser credentials are required.");

                if (!resultDatabase.OrganizerOwnsEnrolment(
                    existing.EnrollmentID, organizerId))
                    return Forbid();

                if (!resultDatabase.DeleteResult(id))
                    return NotFound("Result not found.");

                return NoContent();
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while deleting the result.");
            }
        }
    }
}