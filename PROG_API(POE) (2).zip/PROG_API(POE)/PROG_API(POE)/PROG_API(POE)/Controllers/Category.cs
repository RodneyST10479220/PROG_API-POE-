﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using PROG_API_POE_.Database;
using PROG_API_POE_.Models;

namespace PROG_API_POE_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Category : ControllerBase
    {
        private readonly CategoryDatabase categoryDatabase = new CategoryDatabase();
        private readonly Event eventDatabase = new Event();

        // GET: /api/events/{eventId}/categories
        [HttpGet("/api/events/{eventId}/categories")]
        public IActionResult GetCategories(int eventId)
        {
            if (eventId <= 0)
                return BadRequest("Invalid event ID.");

            var categories =
                categoryDatabase.GetCategoriesByEventId(eventId);

            if (categories == null)
                return NotFound("Event not found.");

            return Ok(categories);
        }

        // POST: /api/events/{eventId}/categories
        [HttpPost("/api/events/{eventId}/categories")]
        public IActionResult CreateCategory(
            int eventId,
            [FromBody] CreateCategoryRequest request,
            [FromHeader(Name = "X-Organizer-Email"), Required] string email,
            [FromHeader(Name = "X-Organizer-Password"), Required] string password)
        {
            if (eventId <= 0)
                return BadRequest("Invalid event ID.");

            int organizerId = eventDatabase.GetOrganizerId(email, password);

            if (organizerId == 0)
                return Unauthorized("Valid organizer credentials are required.");

            try
            {
                var created = categoryDatabase.CreateCategory(
                    eventId, request, organizerId);

                if (created == null)
                    return NotFound(
                        "Event not found, or you do not own this event.");

                return Created(
                    $"/api/categories/{created.CategoryID}", created);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT: /api/categories/{id}
        [HttpPut("/api/categories/{id}")]
        public IActionResult UpdateCategory(
            int id,
            [FromBody] UpdateCategoryRequest request,
            [FromHeader(Name = "X-Organizer-Email"), Required] string email,
            [FromHeader(Name = "X-Organizer-Password"), Required] string password)
        {
            if (id <= 0)
                return BadRequest("Invalid category ID.");

            int organizerId = eventDatabase.GetOrganizerId(email, password);

            if (organizerId == 0)
                return Unauthorized("Valid organizer credentials are required.");

            try
            {
                var updated = categoryDatabase.UpdateCategory(
                    id, request, organizerId);

                if (updated == null)
                    return NotFound(
                        "Category not found, or you do not own its event.");

                return Ok(updated);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // DELETE: /api/categories/{id}
        [HttpDelete("/api/categories/{id}")]
        public IActionResult DeleteCategory(
            int id,
            [FromHeader(Name = "X-Organizer-Email"), Required] string email,
            [FromHeader(Name = "X-Organizer-Password"), Required] string password)
        {
            if (id <= 0)
                return BadRequest("Invalid category ID.");

            int organizerId = eventDatabase.GetOrganizerId(email, password);

            if (organizerId == 0)
                return Unauthorized("Valid organizer credentials are required.");

            bool deleted =
                categoryDatabase.DeleteCategory(id, organizerId);

            if (!deleted)
                return NotFound(
                    "Category not found, or you do not own its event.");

            return NoContent();
        }
    }
}