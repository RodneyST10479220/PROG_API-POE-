﻿namespace PROG_API_POE_.Models
{
    public enum ResultStatus
    {
        Finished,
        DidNotFinish,
        Disqualified
    }

    public class ResultModel
    {
        public int ResultID { get; set; }
        public int EnrollmentID { get; set; }
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public ResultStatus Status { get; set; }
    }

    public class ResultRequest
    {
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public ResultStatus Status { get; set; }
    }
}