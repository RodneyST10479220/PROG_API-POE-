﻿
namespace PROG_API_POE_.Models
{
    public class EnrolmentModel
    {
        public int EnrollmentID { get; set; }
        public int ParticipantID { get; set; }
        public int EventID { get; set; }
        public int CategoryID { get; set; }
        public int RouteID { get; set; }

        public string EventTitle { get; set; } = "";
        public string CategoryName { get; set; } = "";
        public string RouteName { get; set; } = "";
    }

    public class CreateEnrolmentRequest
    {
        public int CategoryId { get; set; }
        public int RouteId { get; set; }
    }

    public enum EnrolmentCreateStatus
    {
        Created,
        AlreadyEnrolled,
        CategoryOrRouteNotFound
    }

    public enum EnrolmentDeleteStatus
    {
        Deleted,
        NotFound,
        Forbidden
    }
}
