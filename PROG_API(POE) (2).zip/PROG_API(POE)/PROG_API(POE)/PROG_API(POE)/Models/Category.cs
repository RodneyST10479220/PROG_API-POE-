﻿namespace PROG_API_POE_.Models
{
    public class CategoryModel
    {

        public int CategoryID { get; set; }
        public string CategoryName { get; set; } = "";
        public int MinAge { get; set; }
        public int MaxAge { get; set; }

    }
}
