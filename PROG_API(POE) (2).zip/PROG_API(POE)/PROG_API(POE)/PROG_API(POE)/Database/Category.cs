﻿
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using PROG_API_POE_.Models;

namespace PROG_API_POE_.Database
{
    public class CategoryDatabase
    {
        private readonly string connectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=api_dbs;Integrated Security=True;";

        // GET: /api/events/{eventId}/categories
        public List<CategoryModel>? GetCategoriesByEventId(int eventId)
        {
            var categories = new List<CategoryModel>();

            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT CategoryID, CategoryName, MinAge, MaxAge
                FROM dbo.Category
                WHERE EventID = @EventID
                ORDER BY CategoryID;", connection);

            command.Parameters.Add("@EventID", SqlDbType.Int).Value = eventId;

            connection.Open();

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    categories.Add(new CategoryModel
                    {
                        CategoryID = reader.GetInt32(0),
                        CategoryName = reader.GetString(1),
                        MinAge = reader.GetInt32(2),
                        MaxAge = reader.GetInt32(3)
                    });
                }
            }

            // Distinguish an event with no categories from a missing event.
            using var checkCommand = new SqlCommand(
                "SELECT COUNT(1) FROM dbo.Event WHERE EventID = @EventID;",
                connection);

            checkCommand.Parameters.Add("@EventID", SqlDbType.Int).Value = eventId;

            if (Convert.ToInt32(checkCommand.ExecuteScalar()) == 0)
                return null;

            return categories;
        }

        // POST: /api/events/{eventId}/categories
        public CategoryModel? CreateCategory(
            int eventId,
            CreateCategoryRequest request,
            int organizerId)
        {
            ValidateAgeRange(request.MinAge, request.MaxAge);
            ValidateCategoryName(request.CategoryName);

            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                INSERT INTO dbo.Category
                    (CategoryName, MinAge, MaxAge, EventID)
                OUTPUT INSERTED.CategoryID
                SELECT @CategoryName, @MinAge, @MaxAge, EventID
                FROM dbo.Event
                WHERE EventID = @EventID
                  AND OrganizerID = @OrganizerID;", connection);

            AddCategoryNameParameter(command, request.CategoryName);

            command.Parameters.Add("@MinAge", SqlDbType.Int).Value =
                request.MinAge;

            command.Parameters.Add("@MaxAge", SqlDbType.Int).Value =
                request.MaxAge;

            command.Parameters.Add("@EventID", SqlDbType.Int).Value =
                eventId;

            command.Parameters.Add("@OrganizerID", SqlDbType.Int).Value =
                organizerId;

            connection.Open();

            object? result = command.ExecuteScalar();

            if (result == null)
                return null;

            return GetCategoryById(Convert.ToInt32(result));
        }

        // PUT: /api/categories/{id}
        public CategoryModel? UpdateCategory(
            int id,
            UpdateCategoryRequest request,
            int organizerId)
        {
            ValidateCategoryName(request.CategoryName);

            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                UPDATE c
                SET CategoryName = @CategoryName
                FROM dbo.Category AS c
                INNER JOIN dbo.Event AS e ON e.EventID = c.EventID
                WHERE c.CategoryID = @ID
                  AND e.OrganizerID = @OrganizerID;", connection);

            AddCategoryNameParameter(command, request.CategoryName);

            command.Parameters.Add("@ID", SqlDbType.Int).Value = id;

            command.Parameters.Add("@OrganizerID", SqlDbType.Int).Value =
                organizerId;

            connection.Open();

            if (command.ExecuteNonQuery() == 0)
                return null;

            return GetCategoryById(id);
        }

        // DELETE: /api/categories/{id}
        public bool DeleteCategory(int id, int organizerId)
        {
            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                DELETE c
                FROM dbo.Category AS c
                INNER JOIN dbo.Event AS e ON e.EventID = c.EventID
                WHERE c.CategoryID = @ID
                  AND e.OrganizerID = @OrganizerID;", connection);

            command.Parameters.Add("@ID", SqlDbType.Int).Value = id;

            command.Parameters.Add("@OrganizerID", SqlDbType.Int).Value =
                organizerId;

            connection.Open();

            return command.ExecuteNonQuery() > 0;
        }

        // Retrieve a single category after creation or update.
        private CategoryModel? GetCategoryById(int id)
        {
            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT CategoryID, CategoryName, MinAge, MaxAge
                FROM dbo.Category
                WHERE CategoryID = @ID;", connection);

            command.Parameters.Add("@ID", SqlDbType.Int).Value = id;

            connection.Open();

            using var reader = command.ExecuteReader();

            if (!reader.Read())
                return null;

            return new CategoryModel
            {
                CategoryID = reader.GetInt32(0),
                CategoryName = reader.GetString(1),
                MinAge = reader.GetInt32(2),
                MaxAge = reader.GetInt32(3)
            };
        }

        private void AddCategoryNameParameter(
            SqlCommand command, string categoryName)
        {
            command.Parameters.Add("@CategoryName", SqlDbType.VarChar, 255)
                .Value = categoryName.Trim();
        }

        private void ValidateCategoryName(string categoryName)
        {
            if (string.IsNullOrWhiteSpace(categoryName))
                throw new ArgumentException("Category name is required.");

            if (categoryName.Trim().Length > 255)
                throw new ArgumentException(
                    "Category name cannot exceed 255 characters.");
        }

        private void ValidateAgeRange(int minAge, int maxAge)
        {
            if (minAge < 0 || maxAge > 120 || minAge > maxAge)
            {
                throw new ArgumentException(
                    "Ages must be between 0 and 120, and minimum age cannot exceed maximum age.");
            }
        }
    }
}
