﻿using Microsoft.Data.SqlClient;
using PROG_API_POE_.Models;
using BCrypt.Net;

namespace PROG_API_POE_.Database
{
    public class Result
    {
        private readonly string connectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=api_dbs;Integrated Security=True;";

        private int GetUserId(string email, string password, out string role)
        {
            role = "";

            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT UserID, PasswordHash, Role
                FROM dbo.Users
                WHERE Email = @Email";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Email", email);

            using SqlDataReader reader = cmd.ExecuteReader();

            if (!reader.Read())
                return 0;

            int userId = Convert.ToInt32(reader["UserID"]);
            string passwordHash = reader["PasswordHash"].ToString() ?? "";
            role = reader["Role"].ToString() ?? "";

            if (!BCrypt.Net.BCrypt.Verify(password, passwordHash))
            {
                role = "";
                return 0;
            }

            return userId;
        }

        public int GetOrganizerId(string email, string password)
        {
            string role;
            int userId = GetUserId(email, password, out role);

            if (userId == 0 || role != "Organizer")
                return 0;

            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT OrganizerID
                FROM dbo.EventOrganizer
                WHERE UserID = @UserID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@UserID", userId);

            object? result = cmd.ExecuteScalar();

            return result == null || result == DBNull.Value
                ? 0
                : Convert.ToInt32(result);
        }

        public int GetParticipantId(string email, string password)
        {
            string role;
            int userId = GetUserId(email, password, out role);

            if (userId == 0 || role != "Participant")
                return 0;

            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT ParticipantID
                FROM dbo.Participant
                WHERE UserID = @UserID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@UserID", userId);

            object? result = cmd.ExecuteScalar();

            return result == null || result == DBNull.Value
                ? 0
                : Convert.ToInt32(result);
        }

        public bool EnrolmentExists(int enrolmentId)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT COUNT(*)
                FROM dbo.EventEnrollment
                WHERE EnrollmentID = @EnrollmentID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@EnrollmentID", enrolmentId);

            return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
        }

        public bool OrganizerOwnsEnrolment(int enrolmentId, int organizerId)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT COUNT(*)
                FROM dbo.EventEnrollment ee
                INNER JOIN dbo.Event e ON ee.EventID = e.EventID
                WHERE ee.EnrollmentID = @EnrollmentID
                  AND e.OrganizerID = @OrganizerID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@EnrollmentID", enrolmentId);
            cmd.Parameters.AddWithValue("@OrganizerID", organizerId);

            return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
        }

        public bool ParticipantOwnsEnrolment(int enrolmentId, int participantId)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT COUNT(*)
                FROM dbo.EventEnrollment
                WHERE EnrollmentID = @EnrollmentID
                  AND ParticipantID = @ParticipantID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@EnrollmentID", enrolmentId);
            cmd.Parameters.AddWithValue("@ParticipantID", participantId);

            return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
        }

        public bool ResultExistsForEnrolment(int enrolmentId)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT COUNT(*)
                FROM dbo.Results
                WHERE EnrollmentID = @EnrollmentID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@EnrollmentID", enrolmentId);

            return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
        }

        public ResultModel? GetResultByEnrolment(int enrolmentId)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT ResultID, EnrollmentID, FinishTime, Position, Status
                FROM dbo.Results
                WHERE EnrollmentID = @EnrollmentID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@EnrollmentID", enrolmentId);

            using SqlDataReader reader = cmd.ExecuteReader();

            if (!reader.Read())
                return null;

            return ReadResult(reader);
        }

        public ResultModel? GetResultById(int id)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                SELECT ResultID, EnrollmentID, FinishTime, Position, Status
                FROM dbo.Results
                WHERE ResultID = @ResultID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@ResultID", id);

            using SqlDataReader reader = cmd.ExecuteReader();

            if (!reader.Read())
                return null;

            return ReadResult(reader);
        }

        public ResultModel CreateResult(int enrolmentId, ResultRequest request)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                INSERT INTO dbo.Results
                    (EnrollmentID, FinishTime, Position, Status)
                OUTPUT INSERTED.ResultID
                VALUES
                    (@EnrollmentID, @FinishTime, @Position, @Status)";

            using SqlCommand cmd = new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@EnrollmentID", enrolmentId);
            cmd.Parameters.AddWithValue("@FinishTime",
                (object?)request.FinishTime ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Position",
                (object?)request.Position ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Status", request.Status.ToString());

            int newId = Convert.ToInt32(cmd.ExecuteScalar());

            return new ResultModel
            {
                ResultID = newId,
                EnrollmentID = enrolmentId,
                FinishTime = request.FinishTime,
                Position = request.Position,
                Status = request.Status
            };
        }

        public ResultModel? UpdateResult(int id, ResultRequest request)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                UPDATE dbo.Results
                SET FinishTime = @FinishTime,
                    Position = @Position,
                    Status = @Status
                WHERE ResultID = @ResultID";

            using SqlCommand cmd = new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@ResultID", id);
            cmd.Parameters.AddWithValue("@FinishTime",
                (object?)request.FinishTime ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Position",
                (object?)request.Position ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Status", request.Status.ToString());

            if (cmd.ExecuteNonQuery() == 0)
                return null;

            return GetResultById(id);
        }

        public bool DeleteResult(int id)
        {
            using SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = @"
                DELETE FROM dbo.Results
                WHERE ResultID = @ResultID";

            using SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@ResultID", id);

            return cmd.ExecuteNonQuery() > 0;
        }

        private ResultModel ReadResult(SqlDataReader reader)
        {
            return new ResultModel
            {
                ResultID = Convert.ToInt32(reader["ResultID"]),
                EnrollmentID = Convert.ToInt32(reader["EnrollmentID"]),
                FinishTime = reader["FinishTime"] == DBNull.Value
                    ? null
                    : (TimeSpan?)reader["FinishTime"],
                Position = reader["Position"] == DBNull.Value
                    ? null
                    : Convert.ToInt32(reader["Position"]),
                Status = Enum.Parse<ResultStatus>(
                    reader["Status"].ToString() ?? "Finished")
            };
        }
    }
}