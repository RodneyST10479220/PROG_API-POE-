﻿
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using PROG_API_POE_.Models;

namespace PROG_API_POE_.Database
{
    public class Enrolment
    {
        private readonly string connectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=api_dbs;Integrated Security=True;";

        // Authenticate a participant and return ParticipantID.
        public int GetParticipantId(string email, string password)
        {
            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT p.ParticipantID, u.PasswordHash
                FROM dbo.Users AS u
                INNER JOIN dbo.Participant AS p
                    ON p.UserID = u.UserID
                WHERE u.Email = @Email
                  AND u.Role = 'Participant';", connection);

            command.Parameters.Add("@Email", SqlDbType.VarChar, 255)
                .Value = email.Trim();

            connection.Open();

            int participantId;
            string passwordHash;

            using (var reader = command.ExecuteReader())
            {
                if (!reader.Read())
                    return 0;

                participantId = reader.GetInt32(0);
                passwordHash = reader.GetString(1);
            }

            return BCrypt.Net.BCrypt.Verify(password, passwordHash)
                ? participantId
                : 0;
        }

        // Authenticate an organizer and return OrganizerID.
        public int GetOrganizerId(string email, string password)
        {
            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT o.OrganizerID, u.PasswordHash
                FROM dbo.Users AS u
                INNER JOIN dbo.EventOrganizer AS o
                    ON o.UserID = u.UserID
                WHERE u.Email = @Email
                  AND u.Role = 'Organizer';", connection);

            command.Parameters.Add("@Email", SqlDbType.VarChar, 255)
                .Value = email.Trim();

            connection.Open();

            int organizerId;
            string passwordHash;

            using (var reader = command.ExecuteReader())
            {
                if (!reader.Read())
                    return 0;

                organizerId = reader.GetInt32(0);
                passwordHash = reader.GetString(1);
            }

            return BCrypt.Net.BCrypt.Verify(password, passwordHash)
                ? organizerId
                : 0;
        }

        // POST: create an enrolment.
        public (EnrolmentCreateStatus Status, EnrolmentModel? Enrolment)
            CreateEnrolment(int participantId, CreateEnrolmentRequest request)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();

            // Check that the category and route exist and belong
            // to the same event.
            using var check = new SqlCommand(@"
                SELECT c.EventID
                FROM dbo.Category AS c
                INNER JOIN dbo.Route AS r
                    ON r.EventID = c.EventID
                WHERE c.CategoryID = @CategoryID
                  AND r.RouteID = @RouteID;", connection);

            check.Parameters.Add("@CategoryID", SqlDbType.Int)
                .Value = request.CategoryId;
            check.Parameters.Add("@RouteID", SqlDbType.Int)
                .Value = request.RouteId;

            object? eventResult = check.ExecuteScalar();

            if (eventResult == null || eventResult == DBNull.Value)
            {
                return (EnrolmentCreateStatus.CategoryOrRouteNotFound, null);
            }

            int eventId = Convert.ToInt32(eventResult);

            // A participant may enrol only once in the same event.
            using var duplicateCheck = new SqlCommand(@"
                SELECT COUNT(1)
                FROM dbo.EventEnrollment
                WHERE ParticipantID = @ParticipantID
                  AND EventID = @EventID;", connection);

            duplicateCheck.Parameters.Add("@ParticipantID", SqlDbType.Int)
                .Value = participantId;
            duplicateCheck.Parameters.Add("@EventID", SqlDbType.Int)
                .Value = eventId;

            if (Convert.ToInt32(duplicateCheck.ExecuteScalar()) > 0)
            {
                return (EnrolmentCreateStatus.AlreadyEnrolled, null);
            }

            using var insert = new SqlCommand(@"
                INSERT INTO dbo.EventEnrollment
                    (ParticipantID, EventID, CategoryID, RouteID)
                OUTPUT INSERTED.EnrollmentID
                VALUES
                    (@ParticipantID, @EventID, @CategoryID, @RouteID);",
                connection);

            insert.Parameters.Add("@ParticipantID", SqlDbType.Int)
                .Value = participantId;
            insert.Parameters.Add("@EventID", SqlDbType.Int)
                .Value = eventId;
            insert.Parameters.Add("@CategoryID", SqlDbType.Int)
                .Value = request.CategoryId;
            insert.Parameters.Add("@RouteID", SqlDbType.Int)
                .Value = request.RouteId;

            int newId = Convert.ToInt32(insert.ExecuteScalar());

            return (EnrolmentCreateStatus.Created, GetEnrolmentById(newId));
        }

        // GET: all enrolments belonging to a participant.
        public List<EnrolmentModel> GetMyEnrolments(int participantId)
        {
            var enrolments = new List<EnrolmentModel>();

            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT ee.EnrollmentID, ee.ParticipantID, ee.EventID,
                       ee.CategoryID, ee.RouteID,
                       e.Title, c.CategoryName, r.RouteName
                FROM dbo.EventEnrollment AS ee
                INNER JOIN dbo.Event AS e ON e.EventID = ee.EventID
                INNER JOIN dbo.Category AS c ON c.CategoryID = ee.CategoryID
                INNER JOIN dbo.Route AS r ON r.RouteID = ee.RouteID
                WHERE ee.ParticipantID = @ParticipantID
                ORDER BY ee.EnrollmentID DESC;", connection);

            command.Parameters.Add("@ParticipantID", SqlDbType.Int)
                .Value = participantId;

            connection.Open();

            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                enrolments.Add(ReadEnrolment(reader));
            }

            return enrolments;
        }

        // Check whether an organizer owns the event for a category.
        public bool OrganizerOwnsCategory(int categoryId, int organizerId)
        {
            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT COUNT(1)
                FROM dbo.Category AS c
                INNER JOIN dbo.Event AS e ON e.EventID = c.EventID
                WHERE c.CategoryID = @CategoryID
                  AND e.OrganizerID = @OrganizerID;", connection);

            command.Parameters.Add("@CategoryID", SqlDbType.Int)
                .Value = categoryId;
            command.Parameters.Add("@OrganizerID", SqlDbType.Int)
                .Value = organizerId;

            connection.Open();

            return Convert.ToInt32(command.ExecuteScalar()) > 0;
        }

        // GET: enrolments in a specific category.
        public List<EnrolmentModel> GetCategoryEnrolments(int categoryId)
        {
            var enrolments = new List<EnrolmentModel>();

            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT ee.EnrollmentID, ee.ParticipantID, ee.EventID,
                       ee.CategoryID, ee.RouteID,
                       e.Title, c.CategoryName, r.RouteName
                FROM dbo.EventEnrollment AS ee
                INNER JOIN dbo.Event AS e ON e.EventID = ee.EventID
                INNER JOIN dbo.Category AS c ON c.CategoryID = ee.CategoryID
                INNER JOIN dbo.Route AS r ON r.RouteID = ee.RouteID
                WHERE ee.CategoryID = @CategoryID
                ORDER BY ee.EnrollmentID;", connection);

            command.Parameters.Add("@CategoryID", SqlDbType.Int)
                .Value = categoryId;

            connection.Open();

            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                enrolments.Add(ReadEnrolment(reader));
            }

            return enrolments;
        }

        // DELETE: cancel an enrolment as its participant or event organizer.
        public EnrolmentDeleteStatus DeleteEnrolment(
            int id, string email, string password)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();

            using var userCommand = new SqlCommand(@"
                SELECT UserID, Role, PasswordHash
                FROM dbo.Users
                WHERE Email = @Email;", connection);

            userCommand.Parameters.Add("@Email", SqlDbType.VarChar, 255)
                .Value = email.Trim();

            int userId;
            string role;
            string passwordHash;

            using (var reader = userCommand.ExecuteReader())
            {
                if (!reader.Read())
                    return EnrolmentDeleteStatus.Forbidden;

                userId = reader.GetInt32(0);
                role = reader.GetString(1);
                passwordHash = reader.GetString(2);
            }

            if (!BCrypt.Net.BCrypt.Verify(password, passwordHash))
                return EnrolmentDeleteStatus.Forbidden;

            string sql;

            if (role == "Participant")
            {
                sql = @"
                    DELETE ee
                    FROM dbo.EventEnrollment AS ee
                    INNER JOIN dbo.Participant AS p
                        ON p.ParticipantID = ee.ParticipantID
                    WHERE ee.EnrollmentID = @ID
                      AND p.UserID = @UserID;";
            }
            else if (role == "Organizer")
            {
                sql = @"
                    DELETE ee
                    FROM dbo.EventEnrollment AS ee
                    INNER JOIN dbo.Event AS e ON e.EventID = ee.EventID
                    INNER JOIN dbo.EventOrganizer AS o
                        ON o.OrganizerID = e.OrganizerID
                    WHERE ee.EnrollmentID = @ID
                      AND o.UserID = @UserID;";
            }
            else
            {
                return EnrolmentDeleteStatus.Forbidden;
            }

            using var delete = new SqlCommand(sql, connection);
            delete.Parameters.Add("@ID", SqlDbType.Int).Value = id;
            delete.Parameters.Add("@UserID", SqlDbType.Int).Value = userId;

            if (delete.ExecuteNonQuery() > 0)
                return EnrolmentDeleteStatus.Deleted;

            using var exists = new SqlCommand(@"
                SELECT COUNT(1)
                FROM dbo.EventEnrollment
                WHERE EnrollmentID = @ID;", connection);

            exists.Parameters.Add("@ID", SqlDbType.Int).Value = id;

            return Convert.ToInt32(exists.ExecuteScalar()) == 0
                ? EnrolmentDeleteStatus.NotFound
                : EnrolmentDeleteStatus.Forbidden;
        }

        private EnrolmentModel? GetEnrolmentById(int id)
        {
            using var connection = new SqlConnection(connectionString);
            using var command = new SqlCommand(@"
                SELECT ee.EnrollmentID, ee.ParticipantID, ee.EventID,
                       ee.CategoryID, ee.RouteID,
                       e.Title, c.CategoryName, r.RouteName
                FROM dbo.EventEnrollment AS ee
                INNER JOIN dbo.Event AS e ON e.EventID = ee.EventID
                INNER JOIN dbo.Category AS c ON c.CategoryID = ee.CategoryID
                INNER JOIN dbo.Route AS r ON r.RouteID = ee.RouteID
                WHERE ee.EnrollmentID = @ID;", connection);

            command.Parameters.Add("@ID", SqlDbType.Int).Value = id;

            connection.Open();

            using var reader = command.ExecuteReader();

            return reader.Read() ? ReadEnrolment(reader) : null;
        }

        private EnrolmentModel ReadEnrolment(SqlDataReader reader)
        {
            return new EnrolmentModel
            {
                EnrollmentID = reader.GetInt32(0),
                ParticipantID = reader.GetInt32(1),
                EventID = reader.GetInt32(2),
                CategoryID = reader.GetInt32(3),
                RouteID = reader.GetInt32(4),
                EventTitle = reader.IsDBNull(5) ? "" : reader.GetString(5),
                CategoryName = reader.IsDBNull(6) ? "" : reader.GetString(6),
                RouteName = reader.IsDBNull(7) ? "" : reader.GetString(7)
            };
        }
    }
}
