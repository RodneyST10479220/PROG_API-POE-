﻿using Microsoft.AspNetCore.Mvc;
using PROG_API_POE_.Controllers;
using PROG_API_POE_.Models;
using Microsoft.AspNetCore.Mvc;
using PROG_API_POE_.Controllers;
using Xunit;

namespace PROG_API_POE_Tests
{
    public class EventControllerTests
    {
        [Fact]
        public void GetAllEvents_ReturnsAResult()
        {
            var controller = new EventController();

            var result = controller.GetAllEvents();

            Assert.NotNull(result);
        }

        [Fact]
        public void GetEventById_ReturnsAResult()
        {
            var controller = new EventController();

            var result = controller.GetEventById(-1);

            Assert.NotNull(result);
        }

        [Fact]
        public void CreateEvent_ReturnsAResult()
        {
            var controller = new EventController();

            var result = controller.CreateEvent(
                null!,
                "invalid@example.com",
                "wrong-password");

            Assert.NotNull(result);
        }

        [Fact]
        public void UpdateEvent_ReturnsAResult()
        {
            var controller = new EventController();

            var result = controller.UpdateEvent(
                -1,
                null!,
                "invalid@example.com",
                "wrong-password");

            Assert.NotNull(result);
        }

        [Fact]
        public void DeleteEvent_ReturnsAResult()
        {
            var controller = new EventController();

            var result = controller.DeleteEvent(
                -1,
                "invalid@example.com",
                "wrong-password");

            Assert.NotNull(result);
        }
    }
}