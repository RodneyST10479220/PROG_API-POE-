﻿
using Microsoft.AspNetCore.Mvc;
using PROG_API_POE_.Controllers;
using PROG_API_POE_.Models;
using Xunit;

namespace PROG_API_POE_Tests
{
    public class ResultsControllerTests
    {
        [Fact]
        public void CreateResult_InvalidEnrolmentId_ReturnsResponse()
        {
            var controller = new ResultsController();

            var result = controller.CreateResult(
                0, null!, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void CreateResult_InvalidRequest_ReturnsResponse()
        {
            var controller = new ResultsController();

            var request = new ResultRequest
            {
                Status = (ResultStatus)999
            };

            var result = controller.CreateResult(
                1, request, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void GetResult_InvalidEnrolmentId_ReturnsResponse()
        {
            var controller = new ResultsController();

            var result = controller.GetResult(
                0, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void UpdateResult_InvalidId_ReturnsResponse()
        {
            var controller = new ResultsController();

            var result = controller.UpdateResult(
                0, null!, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void UpdateResult_InvalidRequest_ReturnsResponse()
        {
            var controller = new ResultsController();

            var request = new ResultRequest
            {
                Status = (ResultStatus)999
            };

            var result = controller.UpdateResult(
                1, request, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void DeleteResult_InvalidId_ReturnsResponse()
        {
            var controller = new ResultsController();

            var result = controller.DeleteResult(
                0, "", "");

            Assert.NotNull(result);
        }
    }
}

