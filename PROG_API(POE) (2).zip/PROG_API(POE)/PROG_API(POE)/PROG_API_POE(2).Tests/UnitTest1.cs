﻿
using Microsoft.AspNetCore.Mvc;
using PROG_API_POE_.Controllers;
using PROG_API_POE_.Models;
using Xunit;

namespace PROG_API_POE_Tests
{
    public class AuthenticationControllerTests
    {
        [Fact]
        public void RegisterUser_InvalidRole_ReturnsBadRequest()
        {
            // Arrange
            var controller = new Authentication_Controller();

            var request = new RegisterRequest
            {
                Name = "Test",
                Surname = "User",
                Email = "test@example.com",
                Password = "TestPassword123!",
                Role = (UserRole)999,// Invalid role
                CellPhoneNumber = "0712345678"
            };

            // Act
            var result = controller.RegisterUser(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public void LoginUser_InvalidCredentials_ReturnsUnauthorized()
        {
            // Arrange
            var controller = new Authentication_Controller();

            var request = new LoginRequest
            {
                Email = "invalid-user@example.com",
                Password = "123@Password",
                Role = (UserRole)999//valid
            };

            // Act
            var result = controller.LoginUser(request);

            // Assert
            Assert.IsType<UnauthorizedObjectResult>(result);
        }
    }
}
