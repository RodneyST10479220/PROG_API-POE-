﻿using Microsoft.AspNetCore.Mvc;
using PROG_API_POE_.Controllers;
using PROG_API_POE_.Models;
using Xunit;

namespace PROG_API_POE_Tests
{
    public class UserProfileTests
    {
        [Fact]
        public void GetProfile_MissingEmail_ReturnsBadRequest()
        {
            // Arrange
            var controller = new User_Profile();

            // Act
            var result = controller.GetProfile("", "Password123!");

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public void GetProfile_MissingPassword_ReturnsBadRequest()
        {
            // Arrange
            var controller = new User_Profile();

            // Act
            var result = controller.GetProfile("test@example.com", "");

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public void UpdateProfile_MissingRequiredFields_ReturnsBadRequest()
        {
            // Arrange
            var controller = new User_Profile();

            var request = new UserProfileRequest
            {
                CurrentEmail = "",
                CurrentPassword = "Password123!",
                NewName = "Test",
                NewEmail = "new@example.com",
                NewRole = UserRole.Organizer
            };

            // Act
            var result = controller.UpdateProfile(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public void UpdateProfile_InvalidRole_ReturnsBadRequest()
        {
            // Arrange
            var controller = new User_Profile();

            var request = new UserProfileRequest
            {
                CurrentEmail = "test@example.com",
                CurrentPassword = "Password123!",
                NewName = "Test",
                NewEmail = "new@example.com",
                NewRole = (UserRole)999
            };

            // Act
            var result = controller.UpdateProfile(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public void UpdateProfile_ParticipantMissingSurname_ReturnsBadRequest()
        {
            // Arrange
            var controller = new User_Profile();

            var request = new UserProfileRequest
            {
                CurrentEmail = "test@example.com",
                CurrentPassword = "Password123!",
                NewName = "Test",
                NewEmail = "new@example.com",
                NewRole = UserRole.Participant,
                NewSurname = "",
                NewCellPhoneNumber = "0712345678"
            };

            // Act
            var result = controller.UpdateProfile(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public void UpdateProfile_ParticipantMissingCellPhoneNumber_ReturnsBadRequest()
        {
            // Arrange
            var controller = new User_Profile();

            var request = new UserProfileRequest
            {
                CurrentEmail = "test@example.com",
                CurrentPassword = "Password123!",
                NewName = "Test",
                NewEmail = "new@example.com",
                NewRole = UserRole.Participant,
                NewSurname = "User",
                NewCellPhoneNumber = ""
            };

            // Act
            var result = controller.UpdateProfile(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }
    }
}
