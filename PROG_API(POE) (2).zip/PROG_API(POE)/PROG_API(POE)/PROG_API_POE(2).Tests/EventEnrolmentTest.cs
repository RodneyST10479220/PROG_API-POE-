﻿using Microsoft.AspNetCore.Mvc;
using PROG_API_POE_.Controllers;
using PROG_API_POE_.Models;
using Xunit;

namespace PROG_API_POE_Tests
{
    public class EventEnrolmentTests
    {
        [Fact]
        public void CreateEnrolment_InvalidCategoryId_ReturnsBadRequest()
        {
            var controller = new Event_Enrolment();

            var request = new CreateEnrolmentRequest
            {
                CategoryId = 0,
                RouteId = 1
            };

            var result = controller.CreateEnrolment(
                request, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void CreateEnrolment_InvalidRouteId_ReturnsBadRequest()
        {
            var controller = new Event_Enrolment();

            var request = new CreateEnrolmentRequest
            {
                CategoryId = 1,
                RouteId = 0
            };

            var result = controller.CreateEnrolment(
                request, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void GetCategoryEnrolments_InvalidCategoryId_ReturnsBadRequest()
        {
            var controller = new Event_Enrolment();

            var result = controller.GetCategoryEnrolments(
                0, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void DeleteEnrolment_InvalidId_ReturnsBadRequest()
        {
            var controller = new Event_Enrolment();

            var result = controller.DeleteEnrolment(
                0, "", "");

            Assert.NotNull(result);
        }
    }
}