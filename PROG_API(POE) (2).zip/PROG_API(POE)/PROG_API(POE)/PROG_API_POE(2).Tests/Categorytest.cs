﻿using Microsoft.AspNetCore.Mvc;
using PROG_API_POE_.Controllers;
using Xunit;

namespace PROG_API_POE_Tests
{
    public class CategoryControllerTests
    {
        [Fact]
        public void GetCategories_ReturnsAnActionResult()
        {
            var controller = new PROG_API_POE_.Controllers.Category();

            var result = controller.GetCategories(0);

            Assert.NotNull(result);
        }

        [Fact]
        public void CreateCategory_ReturnsAnActionResult()
        {
            var controller = new PROG_API_POE_.Controllers.Category();

            var result = controller.CreateCategory(
                0, null!, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void UpdateCategory_ReturnsAnActionResult()
        {
            var controller = new PROG_API_POE_.Controllers.Category();

            var result = controller.UpdateCategory(
                0, null!, "", "");

            Assert.NotNull(result);
        }

        [Fact]
        public void DeleteCategory_ReturnsAnActionResult()
        {
            var controller = new PROG_API_POE_.Controllers.Category();

            var result = controller.DeleteCategory(
                0, "", "");

            Assert.NotNull(result);
        }
    }
}
